
const filters = {}

let highlightflag = false;

function swapHighlight() {
    highlightflag = !highlightflag;
    const clickfunction = highlightflag ? 'highlight(this)' : 'craftItem(this)'
    for (const itemrow of itemimages){
      for (const item of itemrow){
        item.setAttribute('onclick', clickfunction)
      }
    }
  }

import {itemiamges} from './itemscript.js'

console.log(itemimage)